-- ============================================================
--  ПОЛЮС FRAMEWORK — ПРОФЕССИИ (shared)
--  Здесь определяются ВСЕ должности станции. Чтобы добавить
--  свою — скопируй блок и поменяй поля. Имена совпадают с
--  списками ScientistTeams/EngineerTeams в конфиге ПОЛЮС-11 —
--  механики станции (тест крови, заправка огнемёта) сами
--  привяжутся к профессиям.
-- ============================================================

P11FW = P11FW or {}

-- ============ КАТЕГОРИИ ============

P11FW.Categories = {
    { id = "garrison", name = "ВОЕННЫЙ ГАРНИЗОН",  order = 1, color = Color(150, 165, 95)  },
    { id = "science",  name = "НАУЧНЫЙ ПЕРСОНАЛ",  order = 2, color = Color(140, 200, 240) },
    { id = "misc",     name = "БЕЗ НАЗНАЧЕНИЯ",    order = 3, color = Color(170, 170, 170) },
}

-- ============ ДОЛЖНОСТИ ============
--  max     = лимит мест (0 = без лимита)
--  weapons = выдаётся при вступлении/респавне (если класс существует)
--  ammo    = боеприпасы { {класс, кол-во}, ... }
--  models  = варианты внешности (игрок выберет в меню F4)

P11FW.Jobs = {

    recruit = {
        order = 1, category = "misc",
        name = "Новобранец",
        desc = "Ты только сошёл с транспорта на станцию «Полюс-11». Пройди оформление у кадровика или через F4 — без должности тебе не положены ни оружие, ни допуск в отсеки.",
        models = {
            "models/player/Group03/male_01.mdl",
            "models/player/Group03/male_02.mdl",
            "models/player/Group03/male_03.mdl",
            "models/player/Group03/female_01.mdl",
            "models/player/Group03/female_02.mdl",
        },
        color = Color(170, 170, 170),
        weapons = {},
        max = 0,
    },

    guard = {
        order = 2, category = "garrison",
        name = "Рядовой охраны",
        desc = "Охрана периметра и внутренних отсеков комплекса. Подчиняется Начкару. В случае ЧП — держит коридор до прихода подмоги.",
        models = { "models/player/combine_soldier.mdl" },
        color = Color(150, 165, 95),
        weapons = { "weapon_pistol", "weapon_polus11_radio" },
        ammo = { {"pistol", 90} },
        max = 0,
    },

    officer = {
        order = 3, category = "garrison", terminal = true, command = true,
        name = "Начкар / Офицер",
        desc = "Командир караула станции. Расставляет посты, ведёт переговоры, объявляет тревогу. Может отдавать ПРИКАЗЫ (!приказ) и объявлять РОЗЫСК (!розыск). Единственная должность с автоматом. Одно место.",
        models = {
            "models/player/police.mdl",
            "models/player/combine_soldier_prisonguard.mdl",
        },
        color = Color(190, 175, 90),
        weapons = { "weapon_polus11_radio", "weapon_ar2" },
        ammo = { {"ar2", 120} },
        max = 1,
    },

    cook = {
        order = 4, category = "garrison",
        name = "Военный повар / Снабженец",
        desc = "Камбуз, склад, выдача снаряжения. Знает, где лежит каждая бочка с солярой для генератора. Без камбуза гарнизон бунтует к концу смены.",
        models = {
            "models/player/Group01/male_07.mdl",
            "models/player/Group01/male_09.mdl",
        },
        color = Color(205, 150, 90),
        weapons = { "weapon_polus11_radio", "weapon_polus11_ration" },
        max = 2,
    },

    lab = {
        order = 5, category = "science",
        name = "Лаборант",
        desc = "Младший научный состав. Забор образцов, анализы, тесты крови на раскалённой проволоке. Помощник вирусолога в полевых условиях.",
        models = {
            "models/player/mossman.mdl",
            "models/player/kleiner.mdl",
        },
        color = Color(170, 210, 255),
        weapons = { "weapon_polus11_syringe", "weapon_polus11_radio", "weapon_polus11_scalpel" },
        max = 3,
    },

    virologist = {
        order = 6, category = "science", terminal = true,
        name = "Вирусолог",
        desc = "Старший по лаборатории. Единственный, кому доверяют официальное заключение теста крови. Если он заражён и подменит результат — его никто не проверит...",
        models = {
            "models/player/kleiner.mdl",
            "models/player/magnusson.mdl",
        },
        color = Color(140, 200, 240),
        weapons = { "weapon_polus11_syringe", "weapon_polus11_radio", "weapon_polus11_scalpel" },
        max = 2,
    },

    engineer = {
        order = 7, category = "science",
        name = "Инженер-изобретатель",
        desc = "Кустарные огнемёты — его рук дело. Чинит генератор, заправляет струи, следит за проводкой. Против Нечто огонь — единственный аргумент.",
        models = { "models/player/eli.mdl" },
        color = Color(255, 195, 95),
        weapons = { "weapon_polus11_flamethrower", "weapon_polus11_radio" },
        max = 2,
    },
}

-- ============ РЕГИСТРАЦИЯ КОМАНД (team) ============
-- Реальные GMod-команды: цвет в табе/неймтагах, team.GetName и т.д.

local TEAM_BASE = 100 -- индексы 100+, чтобы не задеть чужие

P11FW.JobIds = {}
for id, job in pairs(P11FW.Jobs) do
    P11FW.JobIds[#P11FW.JobIds + 1] = id
end
table.sort(P11FW.JobIds, function(a, b)
    return (P11FW.Jobs[a].order or 99) < (P11FW.Jobs[b].order or 99)
end)

P11FW.JobTeams = {} -- jobId -> team index
P11FW.TeamJobs = {} -- team index -> jobId

for i, id in ipairs(P11FW.JobIds) do
    local t = TEAM_BASE + i - 1
    P11FW.JobTeams[id] = t
    P11FW.TeamJobs[t] = id
    team.SetUp(t, P11FW.Jobs[id].name, P11FW.Jobs[id].color or Color(200, 200, 200), true)
end

-- категории отсортированные (для меню)
P11FW.CategoryList = table.Copy(P11FW.Categories)
table.sort(P11FW.CategoryList, function(a, b) return (a.order or 99) < (b.order or 99) end)

-- ============ ХЕЛПЕРЫ (shared) ============

function P11FW.GetJobId(ply)
    if not IsValid(ply) then return P11FW.Config.DefaultJob end
    return P11FW.TeamJobs[ply:Team()] or P11FW.Config.DefaultJob
end

function P11FW.GetJob(ply)
    return P11FW.Jobs[P11FW.GetJobId(ply)]
end

function P11FW.GetJobName(ply)
    local job = P11FW.GetJob(ply)
    return job and job.name or ""
end

-- сколько человек уже на должности
function P11FW.TeamCount(jobId, except)
    local t = P11FW.JobTeams[jobId]
    if not t then return 0 end
    local n = 0
    for _, p in ipairs(player.GetAll()) do
        if p ~= except and p:Team() == t then n = n + 1 end
    end
    return n
end

function P11FW.JobFull(jobId, except)
    local job = P11FW.Jobs[jobId]
    if not job then return true end
    if (job.max or 0) <= 0 then return false end
    return P11FW.TeamCount(jobId, except) >= job.max
end

-- валидные модели должности (с проверкой существования файла)
function P11FW.ValidModels(job)
    local ok = {}
    for _, m in ipairs(job.models or {}) do
        if file.Exists(m, "GAME") then ok[#ok + 1] = m end
    end
    if #ok == 0 then
        ok[1] = "models/player/Group01/male_01.mdl" -- гарантированный фолбэк
    end
    return ok
end

-- отфильтровать оружие, которого нет на сервере (например, нет polus11)
function P11FW.ValidWeapons(job)
    local ok = {}
    for _, class in ipairs(job.weapons or {}) do
        if weapons.Get(class) or class:StartWith("weapon_") == false then
            ok[#ok + 1] = class
        end
    end
    return ok
end

-- ============ КАСТОМНЫЕ ДОЛЖНОСТИ (созданные в игре админом) ============
-- Регистрируются из data-файла (сервер) или net-синка (клиент).
-- records = { {id, team, name, category, desc, color={r,g,b}, max, models, weapons, order}, ... }

function P11FW.RegisterCustomJobs(records)
    -- снести прежние кастомные
    for id, job in pairs(P11FW.Jobs) do
        if job.custom then
            local t = P11FW.JobTeams[id]
            if t then P11FW.TeamJobs[t] = nil end
            P11FW.JobTeams[id] = nil
            P11FW.Jobs[id] = nil
        end
    end

    for _, rec in ipairs(records or {}) do
        if istable(rec) and isstring(rec.id) and isnumber(rec.team) and isstring(rec.name) then
            local c = istable(rec.color) and rec.color or {}
            P11FW.Jobs[rec.id] = {
                custom   = true,
                terminal = rec.terminal == true,
                order    = tonumber(rec.order) or 100,
                category = isstring(rec.category) and rec.category or "misc",
                name     = rec.name,
                desc     = rec.desc or "",
                models   = istable(rec.models) and rec.models or {},
                weapons  = istable(rec.weapons) and rec.weapons or {},
                max      = tonumber(rec.max) or 0,
                color    = Color(tonumber(c.r) or 210, tonumber(c.g) or 170, tonumber(c.b) or 120),
            }
            P11FW.JobTeams[rec.id] = rec.team
            P11FW.TeamJobs[rec.team] = rec.id
            team.SetUp(rec.team, rec.name, P11FW.Jobs[rec.id].color, true)
        end
    end

    -- пересобрать отсортированный список
    P11FW.JobIds = {}
    for id in pairs(P11FW.Jobs) do
        P11FW.JobIds[#P11FW.JobIds + 1] = id
    end
    table.sort(P11FW.JobIds, function(a, b)
        return (P11FW.Jobs[a].order or 99) < (P11FW.Jobs[b].order or 99)
    end)
end
